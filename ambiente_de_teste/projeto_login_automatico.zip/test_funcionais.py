import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

def configurar_driver():
    """Configura e retorna uma instância do WebDriver do Chrome."""
    print("Configurando o WebDriver...")
    servico = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=servico)
    driver.implicitly_wait(10)
    return driver

# --- Funções de Teste (a lógica interna não muda) ---

def teste_saucedemo_valido(driver):
    """(SUCESSO ESPERADO) Testa o login válido no saucedemo.com."""
    print("\n--- Iniciando Teste 1.1: Sauce Demo (Login Válido) ---")
    try:
        driver.get("https://www.saucedemo.com")
        driver.find_element(By.ID, "user-name").send_keys("standard_user")
        driver.find_element(By.ID, "password").send_keys("secret_sauce")
        driver.find_element(By.ID, "login-button").click()

        if "inventory.html" in driver.current_url:
            print(">>> Teste 1.1 (Válido): SUCESSO. Login realizado e página de produtos carregada.")
        else:
            print(">>> Teste 1.1 (Válido): FALHA. Não redirecionou para a página correta.")
    except Exception as e:
        print(f">>> Teste 1.1 (Válido): Ocorreu um erro inesperado. -> {e}")
    finally:
        time.sleep(1)

def teste_saucedemo_invalido(driver):
    """(SUCESSO ESPERADO) Testa o login inválido e a exibição de erro no saucedemo.com."""
    print("\n--- Iniciando Teste 1.2: Sauce Demo (Login Inválido) ---")
    try:
        driver.get("https://www.saucedemo.com")
        driver.find_element(By.ID, "user-name").send_keys("standard_user")
        driver.find_element(By.ID, "password").send_keys("senha_errada")
        driver.find_element(By.ID, "login-button").click()
        
        mensagem_erro = driver.find_element(By.CSS_SELECTOR, "h3[data-test='error']")
        if mensagem_erro.is_displayed():
            print(">>> Teste 1.2 (Inválido): SUCESSO. Mensagem de erro foi exibida como esperado.")
        else:
            print(">>> Teste 1.2 (Inválido): FALHA. Mensagem de erro não foi encontrada.")
    except Exception as e:
        print(f">>> Teste 1.2 (Inválido): Ocorreu um erro inesperado. -> {e}")
    finally:
        time.sleep(1)

def teste_practicetestautomation_valido(driver):
    """(SUCESSO ESPERADO) Testa o login válido no practicetestautomation.com."""
    print("\n--- Iniciando Teste 2.1: Practice Automation (Login Válido) ---")
    try:
        driver.get("https://practicetestautomation.com/practice-test-login/")
        driver.find_element(By.ID, "username").send_keys("student")
        driver.find_element(By.ID, "password").send_keys("Password123")
        driver.find_element(By.ID, "submit").click()
        
        if "logged-in-successfully" in driver.current_url and driver.find_element(By.LINK_TEXT, "Log out").is_displayed():
             print(">>> Teste 2.1 (Válido): SUCESSO. Login realizado e botão 'Log out' visível.")
        else:
            print(">>> Teste 2.1 (Válido): FALHA no login.")
    except Exception as e:
        print(f">>> Teste 2.1 (Válido): Ocorreu um erro inesperado. -> {e}")
    finally:
        time.sleep(1)

def teste_practicetestautomation_invalido(driver):
    """(SUCESSO ESPERADO) Testa o login inválido no practicetestautomation.com."""
    print("\n--- Iniciando Teste 2.2: Practice Automation (Login Inválido) ---")
    try:
        driver.get("https://practicetestautomation.com/practice-test-login/")
        driver.find_element(By.ID, "username").send_keys("student")
        driver.find_element(By.ID, "password").send_keys("SenhaErrada123")
        driver.find_element(By.ID, "submit").click()
        
        mensagem_erro = driver.find_element(By.ID, "error")
        if mensagem_erro.is_displayed():
             print(">>> Teste 2.2 (Inválido): SUCESSO. Mensagem de erro foi exibida como esperado.")
        else:
            print(">>> Teste 2.2 (Inválido): FALHA. Mensagem de erro não foi encontrada.")
    except Exception as e:
        print(f">>> Teste 2.2 (Inválido): Ocorreu um erro inesperado. -> {e}")
    finally:
        time.sleep(1)

def teste_orangehrm_valido(driver):
    """(SUCESSO ESPERADO) Testa o login válido no OrangeHRM."""
    print("\n--- Iniciando Teste 3.1: OrangeHRM (Login Válido) ---")
    try:
        driver.get("https://opensource-demo.orangehrmlive.com/")
        time.sleep(2)
        driver.find_element(By.NAME, "username").send_keys("Admin")
        driver.find_element(By.NAME, "password").send_keys("admin123")
        driver.find_element(By.CSS_SELECTOR, "button[type='submit']").click()

        if driver.find_element(By.CLASS_NAME, "oxd-topbar-header-breadcrumb").is_displayed():
            print(">>> Teste 3.1 (Válido): SUCESSO. Login realizado e dashboard carregado.")
        else:
            print(">>> Teste 3.1 (Válido): FALHA no login.")
    except Exception as e:
        print(f">>> Teste 3.1 (Válido): Ocorreu um erro inesperado. -> {e}")
    finally:
        time.sleep(1)
        
def teste_orangehrm_invalido(driver):
    """(SUCESSO ESPERADO) Testa o login inválido no OrangeHRM."""
    print("\n--- Iniciando Teste 3.2: OrangeHRM (Login Inválido) ---")
    try:
        driver.get("https://opensource-demo.orangehrmlive.com/")
        time.sleep(2)
        driver.find_element(By.NAME, "username").send_keys("Admin")
        driver.find_element(By.NAME, "password").send_keys("senha_incorreta")
        driver.find_element(By.CSS_SELECTOR, "button[type='submit']").click()
        
        mensagem_erro = driver.find_element(By.CSS_SELECTOR, ".oxd-alert--error")
        if mensagem_erro.is_displayed():
            print(">>> Teste 3.2 (Inválido): SUCESSO. Mensagem de 'Invalid credentials' foi exibida.")
        else:
            print(">>> Teste 3.2 (Inválido): FALHA. Mensagem de erro não foi encontrada.")
    except Exception as e:
        print(f">>> Teste 3.2 (Inválido): Ocorreu um erro inesperado. -> {e}")
    finally:
        time.sleep(1)

# --- Bloco de Execução Principal (ORDEM ALTERADA) ---
if __name__ == "__main__":
    driver = None
    try:
        driver = configurar_driver()

        # Bloco 1: Executando todos os testes com situações INVÁLIDAS primeiro
        print("\n=======================================================")
        print("--- INICIANDO BATERIA DE TESTES COM SITUAÇÕES INVÁLIDAS ---")
        print("=======================================================")
        
        teste_saucedemo_invalido(driver)
        teste_practicetestautomation_invalido(driver)
        teste_orangehrm_invalido(driver)

        # Bloco 2: Executando todos os testes com situações VÁLIDAS
        print("\n\n=====================================================")
        print("--- INICIANDO BATERIA DE TESTES COM SITUAÇÕES VÁLIDAS ---")
        print("=====================================================")

        teste_saucedemo_valido(driver)
        teste_practicetestautomation_valido(driver)
        teste_orangehrm_valido(driver)


        print("\n--- Todos os testes foram concluídos. ---")

    except Exception as e:
        print(f"\nOcorreu um erro geral na execução dos testes: {e}")

    finally:
        if driver:
            driver.quit()
            print("WebDriver fechado com sucesso.")