# Programa de Login Automático

Este programa permite fazer login automático em qualquer site web usando Selenium WebDriver.

## Funcionalidades

- ✅ Login automático em qualquer site
- ✅ Detecção automática de campos de login
- ✅ Suporte a campos personalizados (IDs específicos)
- ✅ Verificação de sucesso do login
- ✅ Interface interativa no terminal

## Pré-requisitos

1. **Python 3.7+** instalado
2. **Google Chrome** instalado
3. **Dependências Python** (instaladas automaticamente)

## Instalação

1. Clone ou baixe os arquivos do projeto
2. Abra o terminal na pasta do projeto
3. Instale as dependências:

```bash
pip install -r requirements.txt
```

## Como usar

1. Execute o programa:
```bash
python login_automatico.py
```

2. Siga as instruções na tela:
   - Digite a URL da página de login
   - Digite o nome de usuário
   - Digite a senha
   - (Opcional) Digite os IDs específicos dos campos

3. O programa irá:
   - Abrir o Chrome automaticamente
   - Navegar para a URL
   - Detectar os campos de login
   - Preencher as credenciais
   - Clicar no botão de login
   - Verificar se o login foi bem-sucedido

## Exemplos de uso

### Login básico (detecção automática):
```
URL da página de login: https://www.saucedemo.com
Nome de usuário: standard_user
Senha: secret_sauce
```

### Login com IDs específicos:
```
URL da página de login: https://meusite.com/login
Nome de usuário: meuusuario
Senha: minhasenha
ID do campo usuário: email
ID do campo senha: senha
ID do botão login: btn-entrar
```

## Sites de teste

Você pode testar com estes sites de demonstração:

1. **SauceDemo**: https://www.saucedemo.com
   - Usuário: `standard_user`
   - Senha: `secret_sauce`

2. **The Internet**: https://the-internet.herokuapp.com/login
   - Usuário: `tomsmith`
   - Senha: `SuperSecretPassword!`

3. **Practice Test Automation**: https://practicetestautomation.com/practice-test-login/
   - Usuário: `student`
   - Senha: `Password123`

## Recursos técnicos

- **Detecção automática**: O programa tenta encontrar campos de login usando múltiplos seletores
- **Flexibilidade**: Suporte a diferentes estruturas de página
- **Verificação de sucesso**: Detecta automaticamente se o login foi bem-sucedido
- **Tratamento de erros**: Mensagens claras em caso de falha

## Solução de problemas

### Erro "Chrome não encontrado"
- Certifique-se de que o Google Chrome está instalado
- O programa baixa automaticamente o ChromeDriver compatível

### Campos não encontrados
- Tente especificar os IDs dos campos manualmente
- Verifique se a URL está correta
- Aguarde a página carregar completamente

### Login falha
- Verifique se as credenciais estão corretas
- Alguns sites podem ter CAPTCHA ou verificação adicional
- Tente novamente após alguns segundos

## Arquivos do projeto

- `login_automatico.py` - Programa principal
- `requirements.txt` - Dependências Python
- `test_funcionais.py` - Testes funcionais existentes
- `README.md` - Este arquivo de documentação
#   A u t o m a - o - T e s t e - d e - S o a f t w a r e  
 